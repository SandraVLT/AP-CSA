import java.util.Scanner;

public class Main {
  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    System.out.println("\n\n You are on at the entrance of an abandoned school. You can go north to the gym, south to the audittorium, east to the caffeteria, and west to a classroom. \n Which way do you want to go (n,e,s,w)?");
    String command = scan.nextLine();
    if (command.equals("n")) 
    {
        System.out.println(" You are in the gym. You can go north to the storage closet, south to the bleachers, east back to the entrance, and west to the back door.");
        command = scan.nextLine();
        if (command.equals("n")){
          System.out.println("You picked the storage closet. You find that its a tunnel with two different directions. West to the kitchen freezer and east to the audittorium back stage.");
          command = scan.nextLine();
          if (command.equals("w")){
            System.out.println("You picked the kitchen freezer. You freezed to death. Game over.");
          }
          else if (command.equals("e")){
          System.out.println("You picked the back stage. You joined Ghost tech crew. Game over.");  
          }
        
        }
        else if (command.equals("e")){
          System.out.println("You picked the bleachers. You decided to take a nap. Game over.");
        }
        else if (command.equals("s")){
          System.out.println("You picked the entrance. You had the chance to go somewhere but now you're trapped. Game over.");
        }
        else if (command.equals("w")){
          System.out.println("You picked the back door. You escaped. Game over.");
        }
    } 
    else if (command.equals("s")){
      System.out.println(" You are in the audittorium. You can go north to the entrance, south back stage, east to the stage, and west to a seat.");
      command = scan.nextLine();
      if (command.equals("n")){
      System.out.println("You picked the entrance. You had the chance to go somewhere but now your trapped. Game over.");
      }
      else if (command.equals("s")){
      System.out.println("You picked the back stage. You find that its a tunnel with two different directions. West to the storage closet and east to the classroom closet.");
      command = scan.nextLine();
      if (command.equals("w")){
            System.out.println("You picked the storage closet. You are hired as a janitor. Game over.");
          }
          else if (command.equals("e")){
          System.out.println("You picked the classroom closet. You reorganize all the class materials. Game over.");  
          }
      }
      else if (command.equals("s")){
      System.out.println("You picked the stage. You performed for the Ghost. Game over.");
      }
      else if (command.equals("w"))
      System.out.println("You picked the seats. You watched a Ghost performances. Game over.");
    }

    else if (command.equals("e")){
      System.out.println(" You are in the caffeteria. You can go north to the kitchen, south to the tables, east to the freezer, and west to a break-out room.");
    }
    else if (command.equals("w")){
      System.out.println(" You are in a classroom. You can go north to the white board, south to the closet, east to the teacher's desk, and west to the hallway.");
    }

    //System.out.println("End of adventure!");   
    scan.close();
  }
}